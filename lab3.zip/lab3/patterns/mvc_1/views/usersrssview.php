<?php
namespace MVC\Views;

class UsersRssView extends RssView {}
